# Senfkorn Holding — Coev Business Pack

**Datum:** 20260802
**Operator:** =====stephanhagenurban1 <3
**Status:** ENTWURFE — kein Notarakt, keine Registereintragung

## Inhalt (Reihenfolge)

1. `Senfkorn_Holding_Notar_Vorbereitung_COEV.pdf` — Step 1 Notar-Prep
2. `Senfkorn_Holding_GmbH_Gesellschaftsvertrag_COEV_MAX_ENTWURF.pdf` — Satzung COEV-MAX
3. `Senfkorn_Holding_GmbH_Gesellschaftsvertrag_ENTWURF.pdf` — älterer Kurz-Entwurf (optional)
4. `Senfkorn_IP_Lizenzvertrag_Holding_zu_UG_ENTWURF.pdf` — IP Holding → UG (+ Meister Hasch Cover privat)
5. `Senfkorn_Holding_Einzahlung_HR_COEV_Step3.pdf` — Step 3 Einzahlung/HR
6. `Senfkorn_Holding_GmbH_COEV_LEGAL_MATRIX.md` — Legal/Coev-Matrix
7. `register/README.md` — Ablageplan für echte Nachweise
8. `builders/` — PDF-Generatoren (reproducible)

## 100 % Legalität

Nur durch Notar (§ 2 GmbHG) + Bareinzahlung EUR 25.000 + HR-Eintragung + Unterschriften IP-Lizenz.

## Firma (Arbeitsstand)

- Senfkorn Holding GmbH (Holding)
- Senfkorn UG (haftungsbeschränkt) (operativ / Lizenznehmer)
- Gesellschafter/GF-Vorschlag: Stephan Hagen Urban, Hoyerswerda
